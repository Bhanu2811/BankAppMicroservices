package com.fis.client.models;

import java.util.List;

public class TransactionDTO {

	@Override
	public String toString() {
		return String.format("TransactionDTO [list=%s]", list);
	}

	private List<Transaction> list;

	public List<Transaction> getList() {
		return list;
	}

	public void setList(List<Transaction> list) {
		this.list = list;
	}

	public TransactionDTO() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	
}
