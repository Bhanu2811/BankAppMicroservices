package com.fis.client.controller;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.client.discovery.DiscoveryClient;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.client.RestTemplate;

import com.fis.client.models.Account;
import com.fis.client.models.AccountDTO;
import com.fis.client.models.ApplicationUser;
import com.fis.client.models.Cart;
import com.fis.client.models.CartDTO;
import com.fis.client.models.Customer;
import com.fis.client.models.CustomerDTO;
import com.fis.client.models.Transaction;
import com.fis.client.models.TransactionDTO;

@Controller
public class ClientController {

	@Autowired
	private RestTemplate restTemplate;
//	@Autowired
//	private DiscoveryClient discoveryClient;
	
	@GetMapping("/")
	public String home() {
		return "home";
	}
	
	@PostMapping("/userlogin")
	public String userLogin(@RequestParam("username") String username,@RequestParam("password") String password , Model model,HttpSession session) {
		System.out.println(username);
		System.out.println(password);
		ApplicationUser user=new ApplicationUser();
		
		user.setUsername(username);
		user.setPassword(password);
		int status;
		try {
			
		ResponseEntity<ApplicationUser> res=restTemplate.postForEntity("http://localhost:8090/authservice/auth", user, ApplicationUser.class);
		ApplicationUser userObj=(ApplicationUser) res.getBody();
		System.out.println(userObj);
		session.setAttribute("userId", userObj.getUserId());
		status=res.getStatusCodeValue();
		System.out.println(res.getStatusCodeValue());
		return "redirect:/showCustomerData";
		}
		catch(Exception e)
		{
			status=400;
			model.addAttribute("message","UserName and Password invalid"+e);		
			
			return "home";
		}	
	}
	
	@GetMapping("/createCustomer")
		public String createCustomer() {
		return "/createCustomer" ;
	}
	@PostMapping("/createCustomer")
		public String createCustomer(@RequestParam("customerName") String customerName,
									 @RequestParam("customermobno") long customermobno,
									 @RequestParam("customermail") String customermail,
									 @RequestParam("customerdob") String customerdob,
									 @RequestParam("customerpermadd") String customerpermadd,
									 @RequestParam("password") String password,
									
									 Model model,HttpSession session) 
	{
		Customer customer= new Customer();
		customer.setCustomerName(customerName);
		customer.setCustomermobno(customermobno);
		customer.setCustomermail(customermail);
		customer.setCustomerdob(customerdob);
		customer.setCustomerpermadd(customerpermadd);
		customer.setPassword(password);
		int status;
		try {
			ResponseEntity<Object> res=restTemplate.postForEntity("http://localhost:8084/cussaccservice/createCustomer", customer, Object.class);
			
			Customer cus=(Customer) res.getBody();
			return "redirect:/showCustomerData";
		}
		catch(Exception e) {
			status=400;
			model.addAttribute("message","UserName and Password invalid"+e);		
			
			return "home";
		}
		
	}
	
	@GetMapping("/showCustomerData")
	public String showCustomerData(HttpSession session) {
		CustomerDTO dto=restTemplate.getForObject("http://localhost:8084/cussaccservice/showCustomerData",CustomerDTO.class);
		//model.addAttribute("ProductList",dto.getList());
		session.setAttribute("CustomerList", dto.getList());
		return "customerList";
	}
	
//	
	@PostMapping("/createAccount")
	public String createAccount(@RequestParam("accounttype") String accounttype,
								 @RequestParam("accopendate")@DateTimeFormat(pattern = "yyyy-MM-dd") LocalDate accopendate,
								 @RequestParam("balance") double balance,
								 @RequestParam("branch") String branch,
								 @RequestParam("id") int id,
								 Model model,HttpSession session) 
{
		System.out.println(id);
		Account account= new Account();
		Customer customer= new Customer();
		customer.setId(id);
		account.setAccounttype(accounttype);
		account.setAccopendate(accopendate);
		account.setBalance(balance);
		account.setBranch(branch);
		account.setCustomer(customer);
		
	
	int status;
	try {
		ResponseEntity<Object> res=restTemplate.postForEntity("http://localhost:8084/cussaccservice/createAccount", account, Object.class);
		
		Account acc=(Account) res.getBody();
		return "redirect:/showCustomerData";
		
	}
	catch(Exception e) {
		status=400;
		model.addAttribute("message","Details are invalid"+e);		
		
		return "home";
	}
	
}
	
//	@PostMapping("/addToCart/{productId}")
//	public String addToCart(@PathVariable("productId") int productId,HttpSession session) {
//		int  userId=0;
//		userId=(int) session.getAttribute("userId");
//		if(userId==0) {
//			return "SessionExpired";
//		}
//		List<Product> list=(List<Product>) session.getAttribute("ProductList");
//		for(Product p:list) {
//			if(p.getProductId()==productId) {
//			Cart cart=new Cart();
//			cart.setUserid(userId);
//			cart.setProductId(productId);
//			cart.setProductname(p.getProductName());
//			cart.setProductPrice(p.getProductPrice());
//			cart.setQuantity(1);
//			cart.setSumTotal(p.getProductPrice());
//			ResponseEntity<Object> res=restTemplate.postForEntity("http://localhost:8084/cartservice/addItem",cart,Object.class);
//			System.out.println(res.getStatusCodeValue());
//			}
//		}
//		return "redirect:/products";
//	}
	
	@GetMapping("/getAllAccounts")
	public String getAllAccounts(HttpSession session) {
		AccountDTO dto= new AccountDTO();
		try {
		dto=restTemplate.getForObject("http://localhost:8084/cussaccservice/getAllAccounts",AccountDTO.class);
		
		List<Account> list=dto.getList();
		System.out.println(list);
		session.setAttribute("AllAccounts", list);
		}
		catch(Exception e) {
			System.out.println(e.getMessage());
			return "accountList";
		}
		return "accountList";
	}
	
	@GetMapping("/deleteAccount/{accNo}")
	public String deleteAccount(@PathVariable("accNo") long accNo) {
		restTemplate.delete("http://localhost:8084/cussaccservice/deleteAccount/"+accNo);
		return"redirect:/getAllAccounts";
	}
	
	@PostMapping("/updateAccount")
	public String updateAccount(@RequestParam("accNo") long AccNo,
			@RequestParam("accounttype") String accounttype,
		 @RequestParam("accopendate")@DateTimeFormat(pattern = "yyyy-MM-dd") LocalDate accopendate,
		 @RequestParam("balance") double balance,
		 @RequestParam("branch") String branch,
		 @RequestParam("id") int id,
		 Model model,HttpSession session) 
		{
		System.out.println(id);
		Account account= new Account();
		Customer customer= new Customer();
		customer.setId(id);
		account.setAccNo(AccNo);
		account.setAccounttype(accounttype);
		account.setAccopendate(accopendate);
		account.setBalance(balance);
		account.setBranch(branch);
		account.setCustomer(customer);
		
		
		int status;
		try {
		ResponseEntity<Object> res=restTemplate.postForEntity("http://localhost:8084/cussaccservice/updateAccount", account, Object.class);
		Account acc=(Account) res.getBody();
		return "redirect:/getAllAccounts";
		
		}
		catch(Exception e) {
		status=400;
		model.addAttribute("message","Details are invalid"+e);		
		
		return "home";
		}
		
		}
	
	@PostMapping("/deposit")
	public String deposit(@RequestParam("accNo") long accNo, @RequestParam("depositAmount") double depositAmount,HttpSession session )
	{   
		Transaction transaction= new Transaction();
		String transstatus=null;
		Date today=new Date();
		try {
		 transstatus = "SUCCESS";
		restTemplate.postForEntity("http://localhost:8084/cussaccservice/deposit/"+accNo, depositAmount,Object.class );
		Account res=restTemplate.getForObject("http://localhost:8084/cussaccservice/getAccount/"+accNo,Account.class);
		//Account acc=(Account) res.getBody();

		return"redirect:/getAllAccounts";
		}
		catch(Exception e){
			transstatus= "FAILED";
			return e.getMessage();
		}
		finally {
			transaction.setAmount(depositAmount);
			transaction.setFromaccount(accNo);
			transaction.setStatus(transstatus);
			transaction.setTranstime(today);
			transaction.setTranstype("Deposit");
			restTemplate.postForEntity("http://localhost:8085/transservice/addTransaction",transaction, Object.class);
		}
		
	}
	
	@PostMapping("/withdraw")
	public String withdraw(@RequestParam("accNo") long accNo, @RequestParam("withdrawAmount") double withdrawAmount )
	{
		Transaction transaction= new Transaction();
		String transstatus=null;
		Date today=new Date();
		try {
		 transstatus = "SUCCESS";
		 restTemplate.postForEntity("http://localhost:8084/cussaccservice/withdraw/"+accNo, withdrawAmount,Object.class );
		Account res=restTemplate.getForObject("http://localhost:8084/cussaccservice/getAccount/"+accNo,Account.class);
		//Account acc=(Account) res.getBody();

		return"redirect:/getAllAccounts";
		}
		catch(Exception e){
			transstatus= "FAILED";
			return e.getMessage();
		}
		finally {
			transaction.setAmount(withdrawAmount);
			transaction.setFromaccount(accNo);
			transaction.setStatus(transstatus);
			transaction.setTranstime(today);
			transaction.setTranstype("Withdraw");
			restTemplate.postForEntity("http://localhost:8085/transservice/addTransaction",transaction, Object.class);
		}
		
		
		
		
	}
	
	@PostMapping("/fundTransfer")
	public String fundTransfer(@RequestParam("fromAcc") long fromAcc, @RequestParam("toAcc") long toAcc,@RequestParam("amount") double amount, HttpSession session )
	{
		
		Transaction transaction= new Transaction();
		Account acc =new Account();
	    acc.setAccNo(fromAcc);
		String transstatus=null;
		Date today=new Date();
		try {
		 transstatus = "SUCCESS";
		 restTemplate.postForEntity("http://localhost:8084/cussaccservice/fundTransfer/"+fromAcc+"/"+toAcc, amount,Object.class );
		Account res=restTemplate.getForObject("http://localhost:8084/cussaccservice/getAccount/"+fromAcc,Account.class);
		//Account acc=(Account) res.getBody();
		Customer customer= res.getCustomer();
		
		System.out.println(res);
		session.setAttribute("accountno", res.getAccNo());
		session.setAttribute("accountdate", res.getAccopendate());
		session.setAttribute("accounttype", res.getAccounttype());
		session.setAttribute("accountbalance", res.getBalance());
		session.setAttribute("accountbranch", res.getBranch());
		session.setAttribute("customerid", customer.getId());
		return"redirect:/getAllAccounts";
		}
		catch(Exception e){
			transstatus= "FAILED";
			return e.getMessage();
		}
		finally {
			transaction.setAmount(amount);
			transaction.setFromaccount(fromAcc);
			transaction.setStatus(transstatus);
			transaction.setToaccount(toAcc);
			transaction.setTranstime(today);
			transaction.setTranstype("Fund Transfer");
			restTemplate.postForEntity("http://localhost:8085/transservice/addTransaction",transaction, Object.class);
		}
	}
	
	@GetMapping("/showTransactionData")
	public String showTransactionData(HttpSession session) {
		TransactionDTO dto=restTemplate.getForObject("http://localhost:8085/transservice/showTransactionData",TransactionDTO.class);
        System.out.println("checking transaction");
		System.out.println(dto.getList());
		session.setAttribute("transactionList",dto.getList());
		return "transactionList";
	}
//	@GetMapping("/placeOrder")
//	public String placeOrder(HttpSession session) {
//		List<Cart> cartList=(List<Cart>) session.getAttribute("cartItems");
//		List<OrderItem> items=new ArrayList();
//		int grandTotal=0;
//		for(Cart c:cartList) {
//			OrderItem o=new OrderItem();
//			//o.setOrderId(0);
//			o.setProductid(c.getProductId());
//			o.setProductName(c.getProductname());
//			o.setProductPrice(c.getProductPrice());
//			o.setQuantity(c.getQuantity());
//			o.setSubTotal(c.getSumTotal());
//			grandTotal+=c.getSumTotal();
//			items.add(o);
//		
//		}
//		session.setAttribute("orderItems",items);
//		session.setAttribute("grandTotal",grandTotal);
//		
//		return "PlaceOrder";
//	}
	
//	@PostMapping("/confirmOrder")
//	public String confirmOrder(@RequestParam("address") String address,@RequestParam("mode") String mode, HttpSession session) {
//		
//		long millis=System.currentTimeMillis();  
//        java.sql.Date date=new java.sql.Date(millis);  
//        if(session.getAttribute("userId")==null) {
//        	return "SessionExpired";
//        }
//		
//		Order order=new Order();
//		order.setDeliveryAddress(address);
//		order.setPaymentMode(mode);
//		order.setOrderAmount((int) session.getAttribute("grandTotal"));
//		order.setUserid((int) session.getAttribute("userId"));
//		order.setOrderItems((List<OrderItem>) session.getAttribute("orderItems"));
//		order.setOrderDate(date);
//		System.out.println(order.getOrderItems());
//		ResponseEntity<Object> res=restTemplate.postForEntity("http://localhost:8085/orderservice/placeOrder", order, Object.class);
//		System.out.println(res.getStatusCodeValue());
//		restTemplate.delete("http://localhost:8084/cartservice/deleteAll");
//		
//		
//		List<Cart> cartList=null;
//		session.setAttribute("cartItems", cartList);
//		
//		return "Thanks";
//	}
	
}
