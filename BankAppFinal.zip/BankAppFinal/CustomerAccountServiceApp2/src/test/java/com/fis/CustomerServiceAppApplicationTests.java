package com.fis;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.Date;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.fis.cusaccapp.models.Customer;
import com.fis.cusaccapp.services.CustomerService;

@SpringBootTest
class CustomerServiceAppApplicationTests {
	@Autowired
	CustomerService cs;

//	@Test     // Adding Customer 
//	public void testAddCustomer() {
//				Customer cus = new Customer("Bhanu",1234576898,"Bhanu@","Bhanu@gmail","23-2-2000",);
//				String msg=cs.(cus);
//				assertEquals("Customer Details are saved",msg);
	//}

}
