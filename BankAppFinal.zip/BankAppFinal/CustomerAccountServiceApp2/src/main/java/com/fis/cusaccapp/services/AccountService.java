package com.fis.cusaccapp.services;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fis.cusaccapp.Exceptions.AccountNotFound;
import com.fis.cusaccapp.Exceptions.NoRecordsException;
import com.fis.cusaccapp.Exceptions.NotEnoughBalance;
import com.fis.cusaccapp.dao.AccountDao;
import com.fis.cusaccapp.models.Account;


@Service
@Transactional
public class AccountService {
	@Autowired
	AccountDao dao;
	
	public boolean createAccount(Account account) {
		// TODO Auto-generated method stub
		Account acc=dao.save(account);
		if(acc!=null)
			return true;
		else
			return false;
		}
	

	
	public Account getAccount(long accNo) throws AccountNotFound {
		// TODO Auto-generated method stub
		Optional<Account> optional = dao.findById(accNo);
		
		Account acc=optional.get();
		if (optional.isPresent()) {
			return acc;
		} else {
			throw new AccountNotFound("Account Not Found");
		}
	
	}

	public List<Account> getAllAccounts() {
		// TODO Auto-generated method stub
		List<Account> list= dao.findAll();
		if(list.isEmpty()) {
			
			return null;
		}
		else {
			return list;
		}
		
	}

	public boolean updateAccount(Account account) {
		// TODO Auto-generated method stub
		Account acc=dao.save(account);
		if(acc!=null)
			return true;
		else
			return false;
		}
	
	

	public boolean deleteAccount(long accNo) throws AccountNotFound{
		// TODO Auto-generated method stub
		
		Optional<Account> optional=dao.findById(accNo);
		Account acc=optional.get();
		System.out.println(acc);
		if(acc!=null) {
			dao.deleteById(accNo);
			return true;
			}
		else {
			throw new NoRecordsException("No record to delete");
		}
	
		
	}
	// This method is to deposit money to account.
	public boolean deposit(long accNo, double depositAmount) throws AccountNotFound {
		// TODO Auto-generated method stub
		Optional<Account> optional = dao.findById(accNo);
		if (optional.isPresent()) {
			//optional.get();
			dao.deposit(accNo, depositAmount);
			return true;
		} else {
			throw new AccountNotFound("Account Not Found");
		}	
	}

	// This method is to withdraw money from account.
	public boolean withdraw(long accNo, double withdrawAmount ) throws AccountNotFound, NotEnoughBalance {
		// TODO Auto-generated method stub
		Optional<Account> optional = dao.findById(accNo);
		if (optional.isPresent()) {
		  if(optional.get().getBalance()>withdrawAmount) {
			  dao.withdraw(accNo, withdrawAmount);
			  return true; 
		  }
		  else {
			  throw new NotEnoughBalance("Not Enough Balance");
		  }
		  
		} else {
			throw new AccountNotFound("Account Not Found");
		}
		
		
	}

	// In the fund transfer i'm using above withdraw and deposit method to do transfer fromAcc to toAcc
	public boolean fundTransfer(long fromAcc, long toAcc, double amount) throws AccountNotFound, NotEnoughBalance {
		// TODO Auto-generated method stub
		Optional<Account> optional = dao.findById(fromAcc);
		Optional<Account> optional1 = dao.findById(toAcc);
		if(optional.isPresent() && optional1.isPresent()) {
			if(optional.get().getBalance()>amount) {
				  dao.withdraw(fromAcc, amount);
				  dao.deposit(toAcc, amount);
				  return true; 
			  }
			  else {
				  throw new NotEnoughBalance("Not Enough Balance");
			  }
		}
		else {
			throw new AccountNotFound("Account Not Found");
		}
		
	}

//	@Override
//	public Double interestEarned(long getAcc, Date todaydate) {
//		// TODO Auto-generated method stub
//		return dao.interestEarned(getAcc, todaydate);
//	}



}
