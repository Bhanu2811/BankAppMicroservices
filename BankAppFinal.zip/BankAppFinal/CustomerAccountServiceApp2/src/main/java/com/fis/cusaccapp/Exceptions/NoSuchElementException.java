package com.fis.cusaccapp.Exceptions;

public class NoSuchElementException extends RuntimeException {

	public NoSuchElementException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}


	
}
