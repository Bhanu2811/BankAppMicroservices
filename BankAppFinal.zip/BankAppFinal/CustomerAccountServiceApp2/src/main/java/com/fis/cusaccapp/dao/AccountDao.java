package com.fis.cusaccapp.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

import com.fis.cusaccapp.models.Account;



public interface AccountDao extends JpaRepository<Account,Long> {
	// This is the interface in dao layer for account transactions
//	public String createAccount(Account account);
//	public Account getAccount(long getAcc); 
//	public List<Account> getAllAccounts();
//	public String updateAccount(Account account);
//	public String deleteAccount(long getacc);
	
	@Query("Update Account set balance=balance+?2 where accNo=?1")
	@Modifying
	public void deposit(long accNo, double depositAmount);
	
	@Query("Update Account set balance=balance-?2 where accNo=?1")
	@Modifying
	public void withdraw(long accNo, double withdrawAmount); 
	// public String fundTransfer(long fromAcc, long toAcc, double amount) throws AccountNotFound, NotEnoughBalance;
	
	//public double interestEarned(long getAcc,Date todaydate);


}
