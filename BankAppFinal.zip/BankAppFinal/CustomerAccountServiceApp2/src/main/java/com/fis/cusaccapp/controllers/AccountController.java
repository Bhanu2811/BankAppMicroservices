package com.fis.cusaccapp.controllers;

import java.util.Date;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fis.cusaccapp.Exceptions.AccountNotFound;
import com.fis.cusaccapp.Exceptions.NotEnoughBalance;
import com.fis.cusaccapp.models.Account;
import com.fis.cusaccapp.models.AccountDTO;
import com.fis.cusaccapp.services.AccountService;

//import com.fis.bankingapp.exceptions.AccountNotFound;
//import com.fis.bankingapp.exceptions.NotEnoughBalance;
//import com.fis.bankingapp.model.Account;
//import com.fis.bankingapp.model.Transaction;
//import com.fis.bankingapp.service.AccountService;
//import com.fis.bankingapp.service.TransactionService;

//{
//    "accopendate": "2023-11-02",
//    "accounttype": "Savings",
//    "balance": 0,
//    "branch": "Hyd"
//}
@RestController
//@RequestMapping("/accounts") // http://localhost:8080/accounts
public class AccountController {
	@Autowired
	AccountService service;
	
//	@Autowired
//	TransactionService transservice;
//	Date today=new Date();
//	String transstatus=null;
	
	@PostMapping("/createAccount") // http://localhost:8080/accounts/createAccount
	public ResponseEntity<Object> createAccount( @RequestBody @Validated Account account) { 
		if(service.createAccount(account)){
			return new ResponseEntity<Object>(HttpStatus.CREATED);
		}
		else
			return new ResponseEntity<Object>(HttpStatus.BAD_REQUEST);
		}
	
	@GetMapping("/getAccount/{accNo}") // http://localhost:8080/accounts/getAccount
	public ResponseEntity<Object> getAccount(@PathVariable("accNo") long accNo) throws AccountNotFound {
			  
				
			return new ResponseEntity<Object>(service.getAccount(accNo),HttpStatus.OK);
			
	}
	
	@GetMapping("/getAllAccounts") // http://localhost:8080/accounts/getAllAccounts
	public ResponseEntity<AccountDTO> getAllAccounts(){
		AccountDTO dto=new AccountDTO();
		dto.setList(service.getAllAccounts());
		return new ResponseEntity<AccountDTO>(dto,HttpStatus.OK);
		
	}
	
	@PostMapping("/updateAccount") // http://localhost:8080/accounts/updateAccount
	public ResponseEntity<Object> updateAccount(@RequestBody Account account) {
		if(service.updateAccount(account)){
			System.out.println("Updation has done please check");
			return new ResponseEntity<Object>(HttpStatus.CREATED);
		}
		else
			return new ResponseEntity<Object>(HttpStatus.BAD_REQUEST);
		}
	
	
	@DeleteMapping("/deleteAccount/{accNo}") // http://localhost:8080/accounts/deleteAccount/3
	public ResponseEntity<Object> deleteAccount(@PathVariable("accNo") long accNo) throws AccountNotFound {
		service.deleteAccount(accNo);
		return new ResponseEntity<Object>(HttpStatus.NO_CONTENT);
	}
	
	@PostMapping("/deposit/{accNo}") //http://localhost:8080/accounts/deposit/3
	public ResponseEntity<Object> deposit(@PathVariable("accNo") long accNo, @RequestBody double depositAmount ) throws AccountNotFound {
		
		System.out.println("This is deposit acc number"+accNo);
		System.out.println("This is deposit amount"+depositAmount);
		
				    service.deposit(accNo, depositAmount);
					return new ResponseEntity<Object>(HttpStatus.OK);
				
	
		     	
		
//		
//		Transaction transaction= new Transaction();
//		
//		try {
//			transstatus = "SUCCESS";
//			return service.deposit(getAcc, depositAmount);
//		}catch(AccountNotFound anf) {
//			transstatus= "FAILED";
//			return anf.getMessage();
//		}
//		finally {
//			transaction.setAmount(depositAmount);
//			transaction.setFromaccount(getAcc);
//			transaction.setTranstime(today);
//			transaction.setTranstype("Deposit");
//			transaction.setStatus(transstatus);
//			transservice.addTransaction(transaction);
//		}
		
		
		
	}
	
	@PostMapping("/withdraw/{accNo}") // http://localhost:8080/accounts/withdraw/4
	public ResponseEntity<Object> withdraw(@PathVariable("accNo") long accNo, @RequestBody Double withdrawAmount  ) throws AccountNotFound, NotEnoughBalance {
	
			// transstatus = "SUCCESS";
			service.withdraw(accNo, withdrawAmount);
			return new ResponseEntity<Object>(HttpStatus.OK);
		
//		finally {
//			Transaction transaction= new Transaction();
//			transaction.setAmount(withdrawAmount);
//			transaction.setFromaccount(getAcc);
//			transaction.setTranstime(today);
//			
//			transaction.setTranstype("Withdraw");
//			transaction.setStatus(transstatus);
//			transservice.addTransaction(transaction);
//		}
		
		
		
	}
	
	@PostMapping("fundTransfer/{fromAcc}/{toAcc}") // http://localhost:8080/accounts/3/4
	public ResponseEntity<Object> fundTransfer(@PathVariable long fromAcc, @PathVariable long toAcc,@RequestBody Double amount) {
		try {
			//transstatus= "SUCCESS";
			service.fundTransfer(fromAcc, toAcc, amount);
			return new ResponseEntity<Object>(HttpStatus.OK);
		}catch(AccountNotFound anf){
			//transstatus= "FAILED";
			return new ResponseEntity<Object>( anf.getMessage(),HttpStatus.NO_CONTENT);
		}
		catch(NotEnoughBalance nef) {
			//transstatus= "FAILED";
			return new ResponseEntity<Object>( nef.getMessage(),HttpStatus.NO_CONTENT);
		}
//		finally {
//			Transaction transaction= new Transaction();
//			transaction.setAmount(amount);
//			transaction.setFromaccount(fromAcc);
//			transaction.setToaccount(toAcc);
//			transaction.setTranstime(today);
//			transaction.setTranstype("Fund Transfer");
//			transaction.setStatus(transstatus);
//			transservice.addTransaction(transaction);
//		}
		
//		@PostMapping("/interestEarned/{getAcc}/{todaydate}")
//		public Double interestEarned( @PathVariable long getAcc, @PathVariable Date todaydate) {
//			return service.interestEarned(getAcc, todaydate);
//		}
//		
		
	}


}
