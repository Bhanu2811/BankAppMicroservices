package com.fis.cusaccapp.services;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

//import com.auth.Exceptions.NoSuchElementException;
import com.fis.cusaccapp.Exceptions.NoRecordsException;
import com.fis.cusaccapp.Exceptions.NoSuchElementException;
import com.fis.cusaccapp.dao.CustomerDao;
import com.fis.cusaccapp.models.Customer;

@Service
@Transactional
public class CustomerService{
    @Autowired
    CustomerDao dao;
	public boolean createCustomer(Customer customer) {
		// TODO Auto-generated method stub
		Customer cus=dao.save(customer);
		//return "Customer Created Successfully";
		if(cus!=null)
			return true;
		else
			return false;
		}
		
	

	public List<Customer> showCustomerData() {
		// TODO Auto-generated method stub
		List<Customer> list=dao.findAll();
		if(list.isEmpty()) {
			return null;
		}
		else {
			return list;
		}
	}
	
	public Customer isValid(String customerName, String password)
	{
		System.out.println(customerName+"In service");
		Customer user=dao.findByCustomerName(customerName);
		if(user==null) {
			throw new NoSuchElementException("No such User");
		}
		else {
			if(password.equals(user.getPassword())) {
				return user;
			}
			else {
				throw new NoSuchElementException("Invalid Password");
			}
		}
	}

}
