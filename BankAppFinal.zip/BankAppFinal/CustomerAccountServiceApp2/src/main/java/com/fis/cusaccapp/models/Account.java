package com.fis.cusaccapp.models;

import java.time.LocalDate;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Past;

import org.springframework.format.annotation.DateTimeFormat;

//import javax.validation.constraints.Max;
//{
//    "accopendate": "2023-11-02",
//    "accounttype": "Savings",
//    "balance": 1000,
//    "branch": "Aundh"
//}
@Entity
@Table(name="Account_details")

public class Account {
	@Id
	@GeneratedValue
	
	private long accNo;
// Gave the relation between customer and account creation so that one customer can have many accounts
	@ManyToOne
	@JoinColumn(name = "id") // id is the foreign key.
	private Customer customer;
	
//	private long customerId;
	@NotBlank(message="accounttype cannot be null or whitespace")
	private String accounttype;
	
	@DateTimeFormat(pattern = "yyyy-MM-dd")
	private LocalDate accopendate=LocalDate.now();
	private double balance;
    @NotBlank(message="accounttype cannot be null or whitespace")
	private String branch;
	
	

	public long getAccNo() {
		return accNo;
	}
	public void setAccountNumber(long accountNumber) {
		this.accNo = accountNumber;
	}
	public Customer getCustomer() {
	        return customer;
	    }

    public void setCustomer(Customer customer) {
	        this.customer = customer;
	    }
	public String getAccounttype() {
		return accounttype;
	}
	public void setAccounttype(String accounttype) {
		this.accounttype = accounttype;
	}
	public LocalDate getAccopendate() {
		return accopendate;
	}
	public void setAccopendate(LocalDate accopendate) {
		this.accopendate = accopendate;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	public String getBranch() {
		return branch;
	}
	public void setBranch(String branch) {
		this.branch = branch;
	}
	

	@Override
	public String toString() {
		return String.format(
				"Account [accNo=%s, customer=%s, accounttype=%s, accopendate=%s, balance=%s, branch=%s]",
				accNo, customer, accounttype, accopendate, balance, branch);
	}
	public Account( long accNo, String accounttype, LocalDate accopendate, double balance,
			String branch) {
		super();
//		this.customerId = customerId;
		this.accNo = accNo;
		this.accounttype = accounttype;
		this.accopendate = accopendate;
		this.balance = balance;
		this.branch = branch;
	}
	
	public Account() {
		
	}

}
