package com.fis.transapp.services;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fis.transapp.dao.TransactionDao;
import com.fis.transapp.models.Transaction;


@Service
@Transactional
public class TransactionService{
	@Autowired
	TransactionDao dao;
	
	public List<Transaction> showTransactionData() {
		// TODO Auto-generated method stub
		List<Transaction> list= dao.findAll();
		if(list.isEmpty()) {
			return null;
		}
		else {
			return list;
		}
	}

	public boolean addTransaction(Transaction transaction) {
		// TODO Auto-generated method stub
		 Transaction trans=dao.save(transaction);
		 if(trans!=null)
				return true;
			else
				return false;
			}
		
	

	public List<Transaction> getTransactionByAcc(long accNo) {
		// TODO Auto-generated method stub
		List<Transaction> list= dao.getTransactionByAcc(accNo);
		if(list.isEmpty()) {
			return null;
		}
		else {
			return list;
		}
		
	}

}
